#include <ArduinoJson.h>
#include <HTTPClient.h>
#include <WiFi.h>
#include <WiFiClientSecure.h>
#include <time.h>

/*
  SIMPLE ESP32 GAS DETECTOR
  -------------------------
  This version does NOT require secrets.h.
  Just edit the values in the CONFIGURATION section below.

  Wiring used by this sketch:
  - MQ2 module signal -> GPIO34
  - Buzzer module I/O -> GPIO26
  - LED -> GPIO27 through 220 ohm resistor
*/

// =========================
// CONFIGURATION
// =========================
const char* WIFI_SSID = "YOUR_WIFI_NAME";
const char* WIFI_PASSWORD = "YOUR_WIFI_PASSWORD";

const char* FIREBASE_RTDB_URL =
    "https://gazdetector-753c1-default-rtdb.firebaseio.com/devices/esp32-gaz-001/latest.json";

constexpr int MQ2_SIGNAL_PIN = 34;
constexpr int BUZZER_PIN = 26;
constexpr int LED_PIN = 27;

constexpr int SAFE_THRESHOLD = 400;
constexpr int WARNING_THRESHOLD = 250;

constexpr int ADC_SAMPLES = 10;
constexpr unsigned long READ_INTERVAL_MS = 1000;
constexpr unsigned long PUSH_INTERVAL_MS = 5000;

unsigned long lastReadAt = 0;
unsigned long lastPushAt = 0;

int readStableSensorValue() {
  long total = 0;
  for (int i = 0; i < ADC_SAMPLES; i++) {
    total += analogRead(MQ2_SIGNAL_PIN);
    delay(15);
  }
  return static_cast<int>(total / ADC_SAMPLES);
}

String currentIsoTimestamp() {
  struct tm timeInfo;
  if (!getLocalTime(&timeInfo, 2000)) {
    return "1970-01-01T00:00:00Z";
  }

  char buffer[25];
  strftime(buffer, sizeof(buffer), "%Y-%m-%dT%H:%M:%SZ", &timeInfo);
  return String(buffer);
}

String gasStatusFromLevel(int gasLevel) {
  if (gasLevel >= SAFE_THRESHOLD) {
    return "danger";
  }
  if (gasLevel >= WARNING_THRESHOLD) {
    return "warning";
  }
  return "safe";
}

void connectToWiFi() {
  if (WiFi.status() == WL_CONNECTED) {
    return;
  }

  Serial.print("Connecting to Wi-Fi");
  WiFi.mode(WIFI_STA);
  WiFi.begin(WIFI_SSID, WIFI_PASSWORD);

  while (WiFi.status() != WL_CONNECTED) {
    delay(500);
    Serial.print(".");
  }

  configTime(0, 0, "pool.ntp.org", "time.nist.gov");

  Serial.println();
  Serial.print("Connected. IP address: ");
  Serial.println(WiFi.localIP());
}

void updateAlarmOutputs(bool danger) {
  digitalWrite(LED_PIN, danger ? HIGH : LOW);
  digitalWrite(BUZZER_PIN, danger ? HIGH : LOW);
}

bool pushToFirebase(int gasLevel, int rawAdcValue) {
  WiFiClientSecure client;
  client.setInsecure();

  HTTPClient https;
  if (!https.begin(client, FIREBASE_RTDB_URL)) {
    Serial.println("Could not open HTTPS connection.");
    return false;
  }

  https.addHeader("Content-Type", "application/json");

  StaticJsonDocument<256> doc;
  doc["gasLevel"] = gasLevel;
  doc["status"] = gasStatusFromLevel(gasLevel);
  doc["timestamp"] = currentIsoTimestamp();
  doc["source"] = "esp32";
  doc["alarmActive"] = gasLevel >= SAFE_THRESHOLD;
  doc["message"] = gasLevel >= SAFE_THRESHOLD
                       ? "Danger alert from ESP32 sensor."
                       : "Live reading from ESP32 sensor.";
  doc["rawAdc"] = rawAdcValue;

  String payload;
  serializeJson(doc, payload);

  const int responseCode = https.PUT(payload);
  Serial.print("Firebase response code: ");
  Serial.println(responseCode);

  https.end();
  return responseCode >= 200 && responseCode < 300;
}

void setup() {
  Serial.begin(115200);

  pinMode(BUZZER_PIN, OUTPUT);
  pinMode(LED_PIN, OUTPUT);

  digitalWrite(BUZZER_PIN, LOW);
  digitalWrite(LED_PIN, LOW);

  analogReadResolution(12);
  analogSetPinAttenuation(MQ2_SIGNAL_PIN, ADC_11db);

  connectToWiFi();
}

void loop() {
  connectToWiFi();

  if (millis() - lastReadAt < READ_INTERVAL_MS) {
    delay(20);
    return;
  }
  lastReadAt = millis();

  const int rawAdcValue = readStableSensorValue();
  const int gasLevel = map(rawAdcValue, 0, 4095, 0, 1000);
  const bool danger = gasLevel >= SAFE_THRESHOLD;

  updateAlarmOutputs(danger);

  Serial.print("ADC: ");
  Serial.print(rawAdcValue);
  Serial.print(" | Gas level: ");
  Serial.print(gasLevel);
  Serial.print(" | Status: ");
  Serial.println(gasStatusFromLevel(gasLevel));

  if (danger || millis() - lastPushAt >= PUSH_INTERVAL_MS) {
    if (pushToFirebase(gasLevel, rawAdcValue)) {
      lastPushAt = millis();
    }
  }
}
