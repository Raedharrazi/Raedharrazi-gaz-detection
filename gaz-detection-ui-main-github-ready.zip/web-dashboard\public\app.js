import { initializeApp } from "https://www.gstatic.com/firebasejs/12.1.0/firebase-app.js";
import {
  getDatabase,
  onValue,
  ref,
  set,
} from "https://www.gstatic.com/firebasejs/12.1.0/firebase-database.js";

const firebaseConfig = {
  apiKey: "AIzaSyBe26kZNYaD2_AJR78J6GlDB-O9yMbI79c",
  authDomain: "gazdetector-753c1.firebaseapp.com",
  databaseURL: "https://gazdetector-753c1-default-rtdb.firebaseio.com",
  projectId: "gazdetector-753c1",
  storageBucket: "gazdetector-753c1.firebasestorage.app",
  messagingSenderId: "646984615573",
  appId: "1:646984615573:web:9dded4d49719342a827d9c",
};

const app = initializeApp(firebaseConfig);
const db = getDatabase(app);
const latestRef = ref(db, "devices/esp32-gaz-001/latest");

const heroCard = document.getElementById("heroCard");
const statusPill = document.getElementById("statusPill");
const syncBadge = document.getElementById("syncBadge");
const gasValue = document.getElementById("gasValue");
const progressBar = document.getElementById("progressBar");
const progressText = document.getElementById("progressText");
const alarmValue = document.getElementById("alarmValue");
const sourceValue = document.getElementById("sourceValue");
const timestampValue = document.getElementById("timestampValue");
const messageText = document.getElementById("messageText");
const jsonPreview = document.getElementById("jsonPreview");

const palette = {
  safe: { tone: "#2ed573", soft: "rgba(46, 213, 115, 0.15)", card: "state-safe" },
  warning: { tone: "#f6b93b", soft: "rgba(246, 185, 59, 0.15)", card: "state-warning" },
  danger: { tone: "#ff5a5f", soft: "rgba(255, 90, 95, 0.15)", card: "state-danger" },
};

function getVisualState(status = "safe", alarmActive = false) {
  if (alarmActive || String(status).toLowerCase() === "danger") return "danger";
  if (String(status).toLowerCase() === "warning") return "warning";
  return "safe";
}

function render(reading = {}) {
  const mode = getVisualState(reading.status, reading.alarmActive);
  const { tone, soft, card } = palette[mode];
  const ppm = Number(reading.gasLevel || 0);
  const progress = Math.max(0, Math.min(100, Math.round((ppm / 1000) * 100)));

  heroCard.classList.remove("state-safe", "state-warning", "state-danger");
  heroCard.classList.add(card);

  statusPill.textContent = mode.toUpperCase();
  statusPill.style.color = tone;
  statusPill.style.background = soft;
  gasValue.textContent = ppm;
  gasValue.parentElement.style.color = tone;
  progressBar.style.width = `${progress}%`;
  progressBar.style.background = tone;
  progressText.textContent = `${progress}% of alert scale`;
  alarmValue.textContent = reading.alarmActive ? "Active" : "Inactive";
  sourceValue.textContent = reading.source || "unknown";
  timestampValue.textContent = reading.timestamp || "Waiting";
  messageText.textContent = reading.message || "Waiting for live sensor data.";
  jsonPreview.textContent = JSON.stringify(reading, null, 2);
  syncBadge.textContent = "Live sync active";
}

function buildTestReading(mode) {
  const timestamp = new Date().toISOString();

  if (mode === "warning") {
    return {
      gasLevel: 320,
      status: "warning",
      timestamp,
      source: "web_test",
      alarmActive: false,
      message: "Browser test mode: warning reading injected.",
    };
  }

  if (mode === "danger") {
    return {
      gasLevel: 620,
      status: "danger",
      timestamp,
      source: "web_test",
      alarmActive: true,
      message: "Browser test mode: danger reading injected.",
    };
  }

  if (mode === "reset") {
    return {
      gasLevel: 0,
      status: "safe",
      timestamp,
      source: "web_test",
      alarmActive: false,
      message: "Alarm reset from browser dashboard.",
    };
  }

  return {
    gasLevel: 120,
    status: "safe",
    timestamp,
    source: "web_test",
    alarmActive: false,
    message: "Browser test mode: safe reading injected.",
  };
}

onValue(
  latestRef,
  (snapshot) => {
    render(snapshot.val() || {});
  },
  (error) => {
    syncBadge.textContent = "Sync error";
    messageText.textContent = `Firebase error: ${error.message}`;
  },
);

document.querySelectorAll("[data-mode]").forEach((button) => {
  button.addEventListener("click", async () => {
    const mode = button.getAttribute("data-mode");
    button.disabled = true;

    try {
      await set(latestRef, buildTestReading(mode));
      syncBadge.textContent = "Write complete";
    } catch (error) {
      syncBadge.textContent = "Write failed";
      messageText.textContent = `Write failed: ${error.message}`;
    } finally {
      button.disabled = false;
    }
  });
});
