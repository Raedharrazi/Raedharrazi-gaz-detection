# ESP32 secrets.h setup

1. Copy `firmware/gas_detector_esp32/secrets.h.example` to `firmware/gas_detector_esp32/secrets.h`.
2. Change:

```cpp
constexpr char WIFI_SSID[] = "REPLACE_WITH_WIFI_NAME";
constexpr char WIFI_PASSWORD[] = "REPLACE_WITH_WIFI_PASSWORD";
```

3. If your Realtime Database URL is different, also change:

```cpp
constexpr char FIREBASE_RTDB_URL[] =
    "https://gazdetector-753c1-default-rtdb.firebaseio.com/devices/esp32-gaz-001/latest.json";
```

4. Save the file and flash the ESP32 from Arduino IDE.
