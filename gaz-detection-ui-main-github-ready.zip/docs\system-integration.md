# System Integration And Simple Test Flow

## End-to-end flow

1. MQ2 detects gas.
2. ESP32 reads the sensor module output.
3. If the level is high, the LED and buzzer turn on.
4. ESP32 sends the reading to Firebase Realtime Database.
5. Android app listens live and updates the dashboard instantly.

## Easiest test order

1. Open Firebase Realtime Database in the console.
2. Create this node:

```json
{
  "devices": {
    "esp32-gaz-001": {
      "latest": {
        "gasLevel": 120,
        "status": "safe",
        "timestamp": "2026-04-24T09:00:00Z",
        "source": "manual_test",
        "alarmActive": false,
        "message": "Manual Firebase console test."
      }
    }
  }
}
```

3. Run the Android app in Android Studio.
4. Confirm the dashboard changes in real time.
5. Use the app test buttons.
6. After that, flash the ESP32 and verify live updates from hardware.

## Common issues

- If the app opens but shows nothing, confirm the Realtime Database URL is correct.
- If Firebase refuses writes, update your Realtime Database rules.
- If the ESP32 keeps restarting, check USB power and MQ2 heater current.
- If the dashboard never changes, confirm both the app and ESP32 are using the same database path.
- If the sensor module is powered at `5V`, identify whether its signal pin is `DO` or `AO` before wiring to the ESP32.
