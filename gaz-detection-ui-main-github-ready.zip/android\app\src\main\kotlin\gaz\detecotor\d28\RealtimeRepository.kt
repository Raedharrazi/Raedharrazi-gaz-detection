package gaz.detecotor.d28

import com.google.firebase.database.DatabaseReference
import com.google.firebase.database.FirebaseDatabase
import com.google.firebase.database.ValueEventListener

class RealtimeRepository {
    private val database: FirebaseDatabase = FirebaseDatabase.getInstance(BuildConfig.FIREBASE_DB_URL)

    private val latestRef: DatabaseReference by lazy {
        database.getReference(BuildConfig.DEVICE_NODE)
    }

    init {
        latestRef.keepSynced(true)
    }

    fun listen(listener: ValueEventListener): Result<Unit> {
        return runCatching {
            latestRef.addValueEventListener(listener)
        }
    }

    fun stop(listener: ValueEventListener): Result<Unit> {
        return runCatching {
            latestRef.removeEventListener(listener)
        }
    }

    fun writeTestReading(
        reading: GasReading,
        onSuccess: () -> Unit,
        onFailure: (Throwable) -> Unit,
    ) {
        runCatching {
            latestRef.setValue(reading)
                .addOnSuccessListener { onSuccess() }
                .addOnFailureListener { onFailure(it) }
        }.onFailure(onFailure)
    }
}
