package gaz.detecotor.d28

import android.app.Application
import com.google.firebase.FirebaseApp
import com.google.firebase.database.FirebaseDatabase

class GasGuardApplication : Application() {
    override fun onCreate() {
        super.onCreate()

        startupError = runCatching {
            FirebaseApp.initializeApp(this) ?: error(
                "Firebase could not initialize. Check google-services.json.",
            )

            FirebaseDatabase
                .getInstance(BuildConfig.FIREBASE_DB_URL)
                .setPersistenceEnabled(true)

            null
        }.getOrElse { error ->
            error.message ?: "Unknown Firebase startup error."
        }
    }

    companion object {
        @Volatile
        var startupError: String? = null
    }
}
