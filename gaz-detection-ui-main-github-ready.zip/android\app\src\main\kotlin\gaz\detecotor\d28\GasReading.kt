package gaz.detecotor.d28

data class GasReading(
    val gasLevel: Int = 0,
    val status: String = "offline",
    val timestamp: String = "",
    val source: String = "unknown",
    val alarmActive: Boolean = false,
    val message: String = "Waiting for data...",
) {
    constructor() : this(0, "offline", "", "unknown", false, "Waiting for data...")
}
