# ESP32 Gas Detector Hardware Assembly

This version matches the parts you described:

- 1 x ESP32 development board
- 1 x MQ2 gas sensor module with 3 pins
- 1 x 5V buzzer module with 3 pins: `I/O`, `GND`, `VCC`
- 1 x LED
- 1 x `220 ohm` resistor for the LED only
- 1 x breadboard used to share `5V` and `GND`
- jumper wires

## Your assembly idea

Yes, you can use the white breadboard as a shared power board:

- one rail for `5V`
- one rail for `GND`

Then both modules take power from those rails.

That is a clean and simple way to wire it.

## Very important note before wiring the sensor signal pin

Your buzzer module is fine to test directly as a module.

The gas sensor module is different:

- if the third pin is a **digital trigger pin** such as `D0`, `DO`, `OUT`, or `S`, it can usually be wired as a logic signal
- if the third pin is an **analog output** such as `A0` or `AO`, you must be careful because a 5V-powered module can output more than `3.3V`

So the fact that the sensor module already has onboard resistors does **not** automatically mean its output is safe for the ESP32.

## Best simple rule

Use this:

- Buzzer module: direct module wiring is acceptable
- Sensor module:
  - if it is `DO` or digital output, use direct signal wiring
  - if it is `AO` or analog output, do **not** connect directly unless you have confirmed the output is limited to `3.3V`

## Shared power rails on the breadboard

Connect power like this first:

1. ESP32 `5V` or `VIN` -> breadboard positive rail
2. ESP32 `GND` -> breadboard ground rail
3. MQ2 module `VCC` -> positive rail
4. MQ2 module `GND` -> ground rail
5. Buzzer module `VCC` -> positive rail
6. Buzzer module `GND` -> ground rail
7. LED cathode -> ground rail

Now both modules share the same `5V` and `GND`.

## Wiring table for your modules

### Power wiring

| Part | Pin | Connect to | Notes |
| --- | --- | --- | --- |
| ESP32 | `5V` or `VIN` | Breadboard `+` rail | Shared 5V rail |
| ESP32 | `GND` | Breadboard `-` rail | Shared ground |
| MQ2 module | `VCC` | Breadboard `+` rail | Module powered from 5V |
| MQ2 module | `GND` | Breadboard `-` rail | Common ground |
| Buzzer module | `VCC` | Breadboard `+` rail | 5V buzzer module supply |
| Buzzer module | `GND` | Breadboard `-` rail | Common ground |

### Signal wiring

| Part | Pin | Connect to | Notes |
| --- | --- | --- | --- |
| Buzzer module | `I/O` | ESP32 `GPIO26` | Direct module trigger test |
| LED | Anode | ESP32 `GPIO27` through `220 ohm` resistor | Only resistor you must keep |
| LED | Cathode | Breadboard `-` rail | Common ground |

### Sensor signal wiring

Use one of these two cases:

#### Case 1: sensor module third pin is `DO`, `OUT`, or `S`

| Part | Pin | Connect to | Notes |
| --- | --- | --- | --- |
| MQ2 module | `DO` / `OUT` / `S` | ESP32 `GPIO34` is **not recommended** | `GPIO34` is input-only and fine for reading, but only if the signal is `3.3V` safe |
| MQ2 module | `DO` / `OUT` / `S` | Better choice: ESP32 `GPIO25` or `GPIO33` | Use if the module signal is confirmed safe for ESP32 logic |

Recommended simple digital wiring:

- MQ2 module signal -> `GPIO33`

#### Case 2: sensor module third pin is `AO` or `A0`

| Part | Pin | Connect to | Notes |
| --- | --- | --- | --- |
| MQ2 module | `AO` / `A0` | ESP32 `GPIO34` | Only if you are sure the signal never exceeds `3.3V` |

If the analog module output can rise toward `5V`, it is **not safe** to connect directly to the ESP32 ADC.

## Recommended assembly for the exact setup you described

Because you want:

- module-to-module wiring
- breadboard shared `5V`
- no extra resistors except the LED

the safest simple practical setup is:

1. use the **buzzer module directly**
2. use the **gas sensor module digital output** if your sensor board has `DO` or `OUT`
3. keep the LED resistor

That gives you the simplest build with no extra signal-divider resistors.

## Exact simple connection map

If your sensor module has a digital output:

- ESP32 `5V` -> breadboard `+`
- ESP32 `GND` -> breadboard `-`
- MQ2 `VCC` -> breadboard `+`
- MQ2 `GND` -> breadboard `-`
- MQ2 `DO` or `OUT` -> ESP32 `GPIO33`
- buzzer `VCC` -> breadboard `+`
- buzzer `GND` -> breadboard `-`
- buzzer `I/O` -> ESP32 `GPIO26`
- LED anode -> ESP32 `GPIO27` through `220 ohm`
- LED cathode -> breadboard `-`

## If your sensor module has only `AO`

Then I do **not** recommend pretending the output is safe just because the board is a module.

In that case you have two honest options:

1. confirm with a multimeter that the signal pin never exceeds `3.3V`
2. or add a level divider for the analog signal

## Buzzer module note

For your 3-pin buzzer module:

- `VCC` -> `5V`
- `GND` -> `GND`
- `I/O` -> ESP32 `GPIO26`

This is the correct simple module wiring.

Most buzzer modules already include what they need on the board, so you usually do not need an extra resistor there.

## LED note

Keep the LED resistor.

Even if your other parts are modules, the LED still needs its own series resistor:

- `220 ohm` is fine

## Final safety notes

- Sharing `5V` on the breadboard is fine.
- Sharing `GND` on the breadboard is mandatory.
- The buzzer module can usually be wired directly to the ESP32 control pin.
- The gas module signal pin must be identified first: `DO` is very different from `AO`.
- Do not assume a 5V sensor module output is ESP32-safe only because the board has onboard resistors.

## What I need from you for the final exact version

Look at the writing next to the sensor module signal pin and tell me whether it says:

- `AO`
- `A0`
- `DO`
- `OUT`
- `S`

If you send that one label, I can give you the final exact pin-to-pin assembly with no guessing.
