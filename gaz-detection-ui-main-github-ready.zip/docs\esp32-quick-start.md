# ESP32 Quick Start Without secrets.h

This version is made to avoid the error:

`fatal error: secrets.h: No such file or directory`

## File to open

Open this file in Arduino IDE:

[gas_detector_esp32.ino](/C:/Users/raedh/Downloads/gaz-detection-ui-main/firmware/gas_detector_esp32/gas_detector_esp32.ino)

## Before compiling

At the top of the file, change only these 3 values:

```cpp
const char* WIFI_SSID = "YOUR_WIFI_NAME";
const char* WIFI_PASSWORD = "YOUR_WIFI_PASSWORD";
const char* FIREBASE_RTDB_URL =
    "https://gazdetector-753c1-default-rtdb.firebaseio.com/devices/esp32-gaz-001/latest.json";
```

### What to put there

- `WIFI_SSID`: your Wi-Fi name
- `WIFI_PASSWORD`: your Wi-Fi password
- `FIREBASE_RTDB_URL`: your Firebase Realtime Database full node URL

## Arduino IDE setup

1. Open Arduino IDE
2. Install the `ESP32` board package if not already installed
3. Select your board:
`Tools -> Board -> ESP32 Dev Module`
4. Select your COM port:
`Tools -> Port -> COMx`

## Required libraries

Make sure these are available:

- `ArduinoJson`
- `WiFi` and `HTTPClient`

`WiFi` and `HTTPClient` usually come with the ESP32 board package.

Install `ArduinoJson` from:

`Sketch -> Include Library -> Manage Libraries`

Search for:

`ArduinoJson`

## Compile and upload

1. Click Verify
2. If compilation passes, click Upload
3. Open Serial Monitor
4. Set baud rate to:
`115200`

## What you should see

If it works, Serial Monitor should show:

- Wi-Fi connection dots
- connected IP address
- ADC value
- gas level
- status
- Firebase response code

## Wiring used by this code

- sensor signal -> `GPIO34`
- buzzer module `I/O` -> `GPIO26`
- LED -> `GPIO27` through `220 ohm`
- modules powered from shared `5V` and `GND` rails

## If compilation still fails

Check these common causes:

1. You copied smart quotes instead of normal quotes
2. The board package is not set to ESP32
3. `ArduinoJson` is not installed
4. You opened the wrong `.ino` file

## If upload works but Firebase does not update

Check:

1. Your Realtime Database rules allow write
2. The database URL is exactly correct
3. Wi-Fi name and password are correct
4. Serial Monitor shows a `200` response code
