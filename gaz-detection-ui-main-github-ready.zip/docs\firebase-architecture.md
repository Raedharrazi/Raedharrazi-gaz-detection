# Native Android + Realtime Database Architecture

## Communication flow

1. The ESP32 reads the MQ2 sensor and writes the latest reading to Firebase Realtime Database over HTTPS.
2. The Android Studio app listens to the same Realtime Database node and updates the dashboard instantly.
3. During testing, the Android app can also write fake `safe`, `warning`, and `danger` values to the database so you can test without the ESP32 first.

## Realtime Database node

```json
/devices/esp32-gaz-001/latest
```

## JSON payload

```json
{
  "gasLevel": 620,
  "status": "danger",
  "timestamp": "2026-04-24T09:15:00Z",
  "source": "esp32",
  "alarmActive": true,
  "message": "Live danger alert from ESP32 sensor.",
  "rawAdc": 2540
}
```

## Why this is simpler

- No Flutter layer
- No Cloud Function required for the basic test path
- One Android app and one Realtime Database node
- You can test from Firebase Console, from the Android app buttons, or from the ESP32
