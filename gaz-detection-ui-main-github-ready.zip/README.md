# GasGuard Native Android

This project has been rebuilt as a native Android Studio app in Kotlin using Firebase Realtime Database.

It now also includes a browser dashboard powered by Node.js at [web-dashboard](/C:/Users/raedh/Downloads/gaz-detection-ui-main/web-dashboard).

## Open in Android Studio

Open:

`C:\Users\raedh\Downloads\gaz-detection-ui-main\android`

## Run the web dashboard

1. Open a terminal in:
`C:\Users\raedh\Downloads\gaz-detection-ui-main\web-dashboard`
2. Run:
`npm start`
3. Open:
[http://localhost:3000](http://localhost:3000)

## Test path

1. Run the app on an emulator or Android phone.
2. Use the built-in test buttons in the dashboard.
3. Write sample data in Firebase Realtime Database.
4. Flash the ESP32 and confirm live updates.

## Before first run

1. Open Firebase Realtime Database in the Firebase console and enable it.
2. If your database URL is not `https://gazdetector-753c1-default-rtdb.firebaseio.com`, change `FIREBASE_DB_URL` in [android/app/build.gradle.kts](/C:/Users/raedh/Downloads/gaz-detection-ui-main/android/app/build.gradle.kts).
3. For easy testing, publish [firebase/database.rules.json](/C:/Users/raedh/Downloads/gaz-detection-ui-main/firebase/database.rules.json) first, then lock it down later.

## Important files

- Android app: [android/app/src/main/kotlin/gaz/detecotor/d28/MainActivity.kt](/C:/Users/raedh/Downloads/gaz-detection-ui-main/android/app/src/main/kotlin/gaz/detecotor/d28/MainActivity.kt)
- Layout: [android/app/src/main/res/layout/activity_main.xml](/C:/Users/raedh/Downloads/gaz-detection-ui-main/android/app/src/main/res/layout/activity_main.xml)
- Firebase config: [android/app/google-services.json](/C:/Users/raedh/Downloads/gaz-detection-ui-main/android/app/google-services.json)
- Realtime DB rules: [firebase/database.rules.json](/C:/Users/raedh/Downloads/gaz-detection-ui-main/firebase/database.rules.json)
- ESP32 firmware: [firmware/gas_detector_esp32/gas_detector_esp32.ino](/C:/Users/raedh/Downloads/gaz-detection-ui-main/firmware/gas_detector_esp32/gas_detector_esp32.ino)
- ESP32 secrets: [firmware/gas_detector_esp32/secrets.h.example](/C:/Users/raedh/Downloads/gaz-detection-ui-main/firmware/gas_detector_esp32/secrets.h.example)
- Web dashboard entry: [web-dashboard/public/index.html](/C:/Users/raedh/Downloads/gaz-detection-ui-main/web-dashboard/public/index.html)
- ESP32 quick start: [docs/esp32-quick-start.md](/C:/Users/raedh/Downloads/gaz-detection-ui-main/docs/esp32-quick-start.md)
