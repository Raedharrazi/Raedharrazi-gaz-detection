package gaz.detecotor.d28

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.snackbar.Snackbar
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.ValueEventListener
import gaz.detecotor.d28.databinding.ActivityMainBinding
import java.time.Instant

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private var repository: RealtimeRepository? = null

    private val realtimeListener = object : ValueEventListener {
        override fun onDataChange(snapshot: DataSnapshot) {
            val reading = snapshot.getValue(GasReading::class.java) ?: GasReading()
            render(reading)
        }

        override fun onCancelled(error: DatabaseError) {
            showMessage("Realtime Database error: ${error.message}")
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        GasGuardApplication.startupError?.let { startupError ->
            renderFatalError(startupError)
            return
        }

        repository = runCatching {
            RealtimeRepository()
        }.getOrElse { error ->
            renderFatalError(error.message ?: "Failed to connect to Realtime Database.")
            return
        }

        setupActions()
        repository?.listen(realtimeListener)?.onFailure { error ->
            renderFatalError(error.message ?: "Realtime Database listener failed.")
        }
    }

    override fun onDestroy() {
        repository?.stop(realtimeListener)
        super.onDestroy()
    }

    private fun setupActions() {
        binding.safeButton.setOnClickListener {
            pushTestReading(
                GasReading(
                    gasLevel = 120,
                    status = "safe",
                    timestamp = nowIso(),
                    source = "android_test",
                    alarmActive = false,
                    message = "Test mode: safe reading injected from Android.",
                ),
            )
        }

        binding.warningButton.setOnClickListener {
            pushTestReading(
                GasReading(
                    gasLevel = 310,
                    status = "warning",
                    timestamp = nowIso(),
                    source = "android_test",
                    alarmActive = false,
                    message = "Test mode: warning reading injected from Android.",
                ),
            )
        }

        binding.dangerButton.setOnClickListener {
            pushTestReading(
                GasReading(
                    gasLevel = 620,
                    status = "danger",
                    timestamp = nowIso(),
                    source = "android_test",
                    alarmActive = true,
                    message = "Danger test: gas threshold exceeded.",
                ),
            )
        }

        binding.resetButton.setOnClickListener {
            pushTestReading(
                GasReading(
                    gasLevel = 0,
                    status = "safe",
                    timestamp = nowIso(),
                    source = "android_test",
                    alarmActive = false,
                    message = "Alarm reset from Android test dashboard.",
                ),
            )
        }
    }

    private fun pushTestReading(reading: GasReading) {
        repository?.writeTestReading(
            reading = reading,
            onSuccess = {
                showMessage("Realtime Database updated.")
            },
            onFailure = { error ->
                showMessage("Write failed: ${error.message}")
            },
        ) ?: run {
            showMessage("Repository is not ready.")
        }
    }

    private fun renderFatalError(message: String) {
        setButtonsEnabled(false)
        binding.statusChip.text = "ERROR"
        binding.statusChip.setChipBackgroundColorResource(R.color.danger_soft)
        binding.statusChip.setTextColor(getColor(R.color.danger))
        binding.gasValueText.text = "--"
        binding.progressText.text = getString(R.string.gas_percent_format, 0)
        binding.gasProgressBar.progress = 0
        binding.gasProgressBar.progressTintList = getColorStateList(R.color.danger)
        binding.gasValueText.setTextColor(getColor(R.color.danger))
        binding.updatedText.text = "Startup problem"
        binding.sourceText.text = "Source: app"
        binding.alarmText.text = "Check setup"
        binding.thresholdText.text = getString(R.string.threshold_format, 400)
        binding.messageText.text = message
        binding.dashboardContainer.setBackgroundResource(R.drawable.bg_panel_danger)
        binding.heroStrip.setBackgroundColor(getColor(R.color.danger))
    }

    private fun render(reading: GasReading) {
        val visual = statusVisual(reading.status, reading.alarmActive)
        val progress = ((reading.gasLevel.coerceAtLeast(0) * 100) / 1000).coerceIn(0, 100)

        binding.statusChip.text = visual.label
        binding.statusChip.setChipBackgroundColorResource(visual.backgroundColor)
        binding.statusChip.setTextColor(getColor(visual.textColor))
        binding.gasValueText.text = getString(R.string.gas_value_format, reading.gasLevel)
        binding.progressText.text = getString(R.string.gas_percent_format, progress)
        binding.gasProgressBar.progress = progress
        binding.gasProgressBar.progressTintList = getColorStateList(visual.heroColor)
        binding.updatedText.text = getString(R.string.updated_format, reading.timestamp.ifBlank { "No timestamp" })
        binding.sourceText.text = getString(R.string.source_format, reading.source)
        binding.thresholdText.text = getString(R.string.threshold_format, 400)
        binding.messageText.text = reading.message
        binding.alarmText.text = if (reading.alarmActive) {
            getString(R.string.alarm_on)
        } else {
            getString(R.string.alarm_off)
        }

        binding.dashboardContainer.setBackgroundResource(visual.panelBackground)
        binding.heroStrip.setBackgroundColor(getColor(visual.heroColor))
        binding.gasValueText.setTextColor(getColor(visual.heroColor))
    }

    private fun setButtonsEnabled(enabled: Boolean) {
        binding.safeButton.isEnabled = enabled
        binding.warningButton.isEnabled = enabled
        binding.dangerButton.isEnabled = enabled
        binding.resetButton.isEnabled = enabled
    }

    private fun showMessage(message: String) {
        Snackbar.make(binding.root, message, Snackbar.LENGTH_SHORT).show()
    }

    private fun nowIso(): String = Instant.now().toString()

    private fun statusVisual(status: String, alarmActive: Boolean): StatusVisual {
        if (alarmActive || status.equals("danger", ignoreCase = true)) {
            return StatusVisual(
                label = "DANGER",
                heroColor = R.color.danger,
                backgroundColor = R.color.danger_soft,
                textColor = R.color.danger,
                panelBackground = R.drawable.bg_panel_danger,
            )
        }

        if (status.equals("warning", ignoreCase = true)) {
            return StatusVisual(
                label = "WARNING",
                heroColor = R.color.warning,
                backgroundColor = R.color.warning_soft,
                textColor = R.color.warning,
                panelBackground = R.drawable.bg_panel_warning,
            )
        }

        return StatusVisual(
            label = "SAFE",
            heroColor = R.color.safe,
            backgroundColor = R.color.safe_soft,
            textColor = R.color.safe,
            panelBackground = R.drawable.bg_panel_safe,
        )
    }
}

private data class StatusVisual(
    val label: String,
    val heroColor: Int,
    val backgroundColor: Int,
    val textColor: Int,
    val panelBackground: Int,
)
